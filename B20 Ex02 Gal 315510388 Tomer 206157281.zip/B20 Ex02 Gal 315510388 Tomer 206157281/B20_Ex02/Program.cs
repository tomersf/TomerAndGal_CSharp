﻿using System;
using System.Collections.Generic;
using System.Text;

namespace B20_Ex02
{ 
    public class Program
    {
        public static void Main()
        {
            List<char> inputArray;
            GamePlay<char>.InitializeDefaultDataArray(out inputArray);
            UI<char> memoryGame = new UI<char>(inputArray);
            memoryGame.StartGame();
        }
    }
}